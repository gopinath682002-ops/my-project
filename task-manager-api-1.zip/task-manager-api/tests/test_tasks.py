import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base, get_db
from app.main import app

engine = create_engine(
    "sqlite://", connect_args={"check_same_thread": False}, poolclass=StaticPool
)
TestingSession = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def override_get_db():
    db = TestingSession()
    try:
        yield db
    finally:
        db.close()


app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(autouse=True)
def fresh_db():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)


client = TestClient(app)
URL = "/api/v1/tasks"


def make(title="Task", **kw):
    return client.post(URL, json={"title": title, **kw})


def test_create_and_get():
    r = make("Write report", description="Q3")
    assert r.status_code == 201
    body = r.json()
    assert body["title"] == "Write report" and body["completed"] is False
    assert client.get(f"{URL}/{body['id']}").json()["description"] == "Q3"


def test_blank_title_rejected():
    r = make("   ")
    assert r.status_code == 422
    assert r.json()["error"]["message"] == "Validation failed"


def test_list_filters_and_pagination():
    make("a"); make("b", completed=True); make("c")
    assert client.get(URL).json()["total"] == 3
    assert client.get(URL, params={"status": "completed"}).json()["total"] == 1
    assert client.get(URL, params={"status": "pending"}).json()["total"] == 2
    page = client.get(URL, params={"limit": 2}).json()
    assert len(page["items"]) == 2 and page["total"] == 3
    assert client.get(URL, params={"search": "b"}).json()["total"] == 1


def test_invalid_filter():
    assert client.get(URL, params={"status": "nope"}).status_code == 422


def test_put_and_patch():
    tid = make("old").json()["id"]
    r = client.put(f"{URL}/{tid}", json={"title": "new", "description": "d", "completed": False})
    assert r.json()["title"] == "new"
    r = client.patch(f"{URL}/{tid}", json={"completed": True})
    assert r.json()["completed"] is True and r.json()["title"] == "new"
    assert client.patch(f"{URL}/{tid}", json={}).status_code == 400


def test_delete():
    tid = make().json()["id"]
    assert client.delete(f"{URL}/{tid}").status_code == 204
    r = client.get(f"{URL}/{tid}")
    assert r.status_code == 404
    assert r.json()["error"]["code"] == 404


def test_not_found_everywhere():
    assert client.put(f"{URL}/999", json={"title": "x"}).status_code == 404
    assert client.patch(f"{URL}/999", json={"title": "x"}).status_code == 404
    assert client.delete(f"{URL}/999").status_code == 404


def test_health():
    assert client.get("/health").json() == {"status": "ok"}
