from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator


def _clean_title(v: str) -> str:
    v = v.strip()
    if not v:
        raise ValueError("title must not be blank")
    return v


class TaskCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200, examples=["Buy groceries"])
    description: str = Field(default="", max_length=2000)
    completed: bool = False

    _title = field_validator("title")(_clean_title)


class TaskUpdate(BaseModel):
    """Partial update (PATCH): only the fields you send are changed."""

    title: Optional[str] = Field(default=None, min_length=1, max_length=200)
    description: Optional[str] = Field(default=None, max_length=2000)
    completed: Optional[bool] = None

    @field_validator("title")
    @classmethod
    def _title(cls, v):
        return _clean_title(v) if v is not None else v


class TaskOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    description: str
    completed: bool
    created_at: datetime
    updated_at: datetime


class TaskPage(BaseModel):
    items: List[TaskOut]
    total: int
    skip: int
    limit: int
