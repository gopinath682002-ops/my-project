from enum import Enum
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy.orm import Session

from .. import crud, schemas
from ..database import get_db

router = APIRouter(prefix="/api/v1/tasks", tags=["Tasks"])


class StatusFilter(str, Enum):
    all = "all"
    completed = "completed"
    pending = "pending"


def _get_or_404(db: Session, task_id: int):
    task = crud.get_task(db, task_id)
    if task is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, f"Task with id {task_id} not found")
    return task


@router.post("", response_model=schemas.TaskOut, status_code=status.HTTP_201_CREATED)
def create_task(data: schemas.TaskCreate, db: Session = Depends(get_db)):
    return crud.create_task(db, data)


@router.get("", response_model=schemas.TaskPage)
def list_tasks(
    status_filter: StatusFilter = Query(StatusFilter.all, alias="status"),
    search: Optional[str] = Query(None, max_length=100, description="Search in title"),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
):
    items, total = crud.list_tasks(db, status_filter.value, search, skip, limit)
    return {"items": items, "total": total, "skip": skip, "limit": limit}


@router.get("/{task_id}", response_model=schemas.TaskOut)
def get_task(task_id: int, db: Session = Depends(get_db)):
    return _get_or_404(db, task_id)


@router.put("/{task_id}", response_model=schemas.TaskOut)
def replace_task(task_id: int, data: schemas.TaskCreate, db: Session = Depends(get_db)):
    task = _get_or_404(db, task_id)
    return crud.update_task(db, task, data.model_dump())


@router.patch("/{task_id}", response_model=schemas.TaskOut)
def update_task(task_id: int, data: schemas.TaskUpdate, db: Session = Depends(get_db)):
    task = _get_or_404(db, task_id)
    changes = data.model_dump(exclude_unset=True)
    if not changes:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "No fields provided to update")
    if changes.get("title") is None and "title" in changes:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, "title cannot be null")
    return crud.update_task(db, task, changes)


@router.delete("/{task_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_task(task_id: int, db: Session = Depends(get_db)):
    crud.delete_task(db, _get_or_404(db, task_id))
    return Response(status_code=status.HTTP_204_NO_CONTENT)
