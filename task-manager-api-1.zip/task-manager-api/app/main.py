from fastapi import FastAPI

from .config import settings
from .database import Base, engine
from .exceptions import register_exception_handlers
from .routers import tasks

Base.metadata.create_all(bind=engine)

app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    description="Simple task manager REST API (FastAPI + SQLAlchemy).",
)
register_exception_handlers(app)
app.include_router(tasks.router)


@app.get("/", tags=["Health"])
def root():
    return {"message": "Task Manager API is running", "docs": "/docs"}


@app.get("/health", tags=["Health"])
def health():
    return {"status": "ok"}
