from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Task Manager API"
    database_url: str = "sqlite:///./tasks.db"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
