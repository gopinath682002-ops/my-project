from typing import Optional, Tuple, List

from sqlalchemy.orm import Session

from . import models, schemas


def list_tasks(
    db: Session, status: str = "all", search: Optional[str] = None, skip: int = 0, limit: int = 20
) -> Tuple[List[models.Task], int]:
    q = db.query(models.Task)
    if status == "completed":
        q = q.filter(models.Task.completed.is_(True))
    elif status == "pending":
        q = q.filter(models.Task.completed.is_(False))
    if search:
        q = q.filter(models.Task.title.ilike(f"%{search}%"))
    total = q.count()
    items = q.order_by(models.Task.id.desc()).offset(skip).limit(limit).all()
    return items, total


def get_task(db: Session, task_id: int) -> Optional[models.Task]:
    return db.get(models.Task, task_id)


def create_task(db: Session, data: schemas.TaskCreate) -> models.Task:
    task = models.Task(**data.model_dump())
    db.add(task)
    db.commit()
    db.refresh(task)
    return task


def update_task(db: Session, task: models.Task, changes: dict) -> models.Task:
    for key, value in changes.items():
        setattr(task, key, value)
    db.commit()
    db.refresh(task)
    return task


def delete_task(db: Session, task: models.Task) -> None:
    db.delete(task)
    db.commit()
