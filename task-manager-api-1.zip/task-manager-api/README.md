# Task Manager API

A REST API for managing tasks, built with **FastAPI**, **SQLAlchemy**, and **SQLite** (PostgreSQL supported).

## Features
- Full CRUD for tasks (create, read, update, delete)
- Filter by status (`all` / `completed` / `pending`), title search, and pagination
- Request validation with clear, consistent JSON error responses
- Layered structure: routers → CRUD layer → models
- Auto-generated interactive docs (Swagger UI at `/docs`)
- Automated tests with pytest

## Project structure
```
app/
  main.py          # app creation, router registration
  config.py        # settings from environment / .env
  database.py      # engine, session, get_db dependency
  models.py        # SQLAlchemy models
  schemas.py       # Pydantic request/response schemas
  crud.py          # database operations
  exceptions.py    # global error handlers
  routers/tasks.py # API endpoints
tests/test_tasks.py
```

## Setup
```bash
git clone <your-repo-url>
cd task-manager-api
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open **http://127.0.0.1:8000/docs** to try the API.

### Use PostgreSQL (optional)
```bash
pip install psycopg2-binary
cp .env.example .env   # set DATABASE_URL=postgresql://user:password@localhost:5432/taskdb
```

## Endpoints
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/v1/tasks` | Create a task |
| GET | `/api/v1/tasks` | List tasks (`status`, `search`, `skip`, `limit`) |
| GET | `/api/v1/tasks/{id}` | Get one task |
| PUT | `/api/v1/tasks/{id}` | Replace a task |
| PATCH | `/api/v1/tasks/{id}` | Partially update (e.g. mark completed) |
| DELETE | `/api/v1/tasks/{id}` | Delete a task |
| GET | `/health` | Health check |

### Example
```bash
curl -X POST http://127.0.0.1:8000/api/v1/tasks \
  -H "Content-Type: application/json" \
  -d '{"title": "Finish assignment", "description": "Submit by Friday"}'

curl "http://127.0.0.1:8000/api/v1/tasks?status=pending"

curl -X PATCH http://127.0.0.1:8000/api/v1/tasks/1 \
  -H "Content-Type: application/json" -d '{"completed": true}'
```

### Error format
```json
{ "error": { "code": 404, "message": "Task with id 99 not found" } }
```
Validation errors (422) include a `details` list with the field and message.

| Code | Meaning |
|---|---|
| 201 / 204 | Created / Deleted |
| 400 | Bad request (e.g. empty PATCH) |
| 404 | Task not found |
| 422 | Validation failed |
| 500 | Server or database error |

## Tests
```bash
pip install -r requirements-dev.txt
pytest
```

## Push to GitHub
```bash
git init
git add .
git commit -m "Initial commit: Task Manager API"
git branch -M main
git remote add origin https://github.com/<your-username>/task-manager-api.git
git push -u origin main
```
